# RPG16
a texture pack for the server capture the flag
created by : Hello-death & deathblade

## Game Support
The following games are supported:

- Capture the Flag

## Mod Support
In addition to the games, the following mods are supported:

- Basic Grenades
- Basic Materials
- Email
- Moon Phases
- Simple Shooter
- [Stamina](https://content.minetest.net/packages/sofar/stamina/)

## Contact
For questions, requests, and other problems regarding this texturepack, you can
contact the creator at gautamiyer2009@gmail.com
